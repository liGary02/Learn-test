import React, { useState, useEffect, useMemo } from "react";
import { createRoot } from "react-dom/client";
import { GoogleGenAI } from "@google/genai";
import { 
  Smartphone, 
  RefreshCw, 
  Type, 
  Tag, 
  Share2, 
  MessageCircle, 
  Heart, 
  MoreHorizontal, 
  Info, 
  User,
  Image as ImageIcon,
  Copy,
  Download,
  Check,
  Upload,
  X,
  Edit3
} from "lucide-react";

// --- Configuration & Initialization ---
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// --- Utilities for Randomness ---
// Mulberry32 is a simple, fast, deterministic PRNG.
function mulberry32(a: number) {
    return function() {
      var t = a += 0x6D2B79F5;
      t = Math.imul(t ^ t >>> 15, t | 1);
      t ^= t + Math.imul(t ^ t >>> 7, t | 61);
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    }
}

// --- Types ---
type ContentType = "news" | "creative";
type LabelType = "none" | "platform" | "user";

interface Comment {
  id: number;
  name: string;
  avatarSeed: string;
  content: string;
  likeCount: number;
}

// --- Helper Functions for URL State ---
interface SharedState {
    c: ContentType;
    l: LabelType;
    t: string;      // topic
    tt: string;     // title
    tx: string;     // text
    h?: string[];   // hashtags (new)
    a: string;      // author (kept for avatar seed)
    lk: string;     // likes
    cc: string;     // commentsCount
    s: number;      // seed
}

const encodeState = (data: SharedState) => {
  try {
    // encodeURIComponent ensures all utf-8 chars are safe
    const jsonStr = JSON.stringify(data);
    return btoa(encodeURIComponent(jsonStr));
  } catch (e) {
    console.error("Encoding failed", e);
    return "";
  }
};

const decodeState = (str: string): SharedState | null => {
  try {
    const fixedStr = str.replace(/ /g, '+');
    const jsonStr = decodeURIComponent(atob(fixedStr));
    return JSON.parse(jsonStr);
  } catch (e) {
    console.error("Decoding failed", e);
    return null;
  }
};

const App = () => {
  // --- Initialization Logic ---
  const urlParams = new URLSearchParams(window.location.search);
  const paramS = urlParams.get('s');
  const sharedState = paramS ? decodeState(paramS) : null;
  const isParticipantView = !!sharedState;

  // --- State ---
  const [contentType, setContentType] = useState<ContentType>(sharedState?.c || "news");
  const [labelType, setLabelType] = useState<LabelType>(sharedState?.l || "platform");
  const [topic, setTopic] = useState<string>(sharedState?.t || "最新智能手机发布");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  
  // Generated Content State
  const [generatedText, setGeneratedText] = useState<string>(sharedState?.tx || "");
  const [generatedTitle, setGeneratedTitle] = useState<string>(sharedState?.tt || "");
  const [generatedHashtags, setGeneratedHashtags] = useState<string[]>(sharedState?.h || ["#科技", "#生活"]);
  
  // Image State (Now handled via manual upload)
  const [generatedImage, setGeneratedImage] = useState<string>(""); 
  
  // Simulation State
  // We keep authorName state for the Avatar seed, but we won't display the text.
  const [authorName, setAuthorName] = useState<string>(sharedState?.a || "科技前沿观察");
  const [likes, setLikes] = useState<string>(sharedState?.lk || "125"); 
  const [commentsCount, setCommentsCount] = useState<string>(sharedState?.cc || "20");
  
  // Seed for comments
  const [seed, setSeed] = useState<number>(sharedState?.s || Math.floor(Math.random() * 100000));
  
  // UI State
  const [copySuccess, setCopySuccess] = useState(false);

  // --- Logic ---

  const mockComments = useMemo(() => {
    const rng = mulberry32(seed);
    const getRandom = (arr: string[]) => arr[Math.floor(rng() * arr.length)];
    
    const seeds = ["Felix", "Aneka", "Zoe", "Jack", "Bandit", "Mimi", "Bella", "Trouble", "Coco", "Simba", "Abby", "Lucy", "Rocky", "Luna", "Oliver"];
    const names = ["小柠檬", "TechExplorer", "CityWalker", "书香", "用户9527", "MorningStar", "J_Design", "云朵", "CyberPunk", "CoffeeLover", "路人甲", "SimpleLife", "BlueSky", "Reader_01"];
    
    const newsComments = ["确实是这样。", "期待。", "这一点很有趣。", "感谢分享。", "有没有更多细节？", "不明觉厉。", "客观中立，点赞。", "坐等后续。", "分析得很到位。", "这也是一种趋势。"];
    const creativeComments = ["太美了！", "很有感觉。", "我也想去。", "文笔真好。", "共鸣。", "爱了爱了。", "照片拍的真好。", "生活就是这样。", "被治愈了。", "真诚的文字最打动人。"];
    
    const pool = contentType === 'news' ? newsComments : creativeComments;
    
    const comments: Comment[] = [];
    for(let i = 0; i < 3; i++) {
        comments.push({
            id: i,
            name: getRandom(names),
            avatarSeed: getRandom(seeds) + i,
            content: getRandom(pool),
            likeCount: Math.floor(rng() * 10)
        });
    }
    return comments;
  }, [seed, contentType]);

  useEffect(() => {
    if (isParticipantView) return;
    if (contentType === 'news') {
      setAuthorName("每日科技速递");
    } else {
      setAuthorName("生活记录者_Annie");
    }
    setSeed(Math.floor(Math.random() * 100000));
  }, [contentType, isParticipantView]);

  const generateContent = async () => {
    if (!topic) return;
    setIsLoading(true);

    try {
      const systemInstruction = "You are a social media content generator. Generate content in Chinese.";
      
      let prompt = "";
      if (contentType === 'news') {
        prompt = `Write a social media post about "${topic}". 
        Style: Objective, informative, journalistic, neutral tone. 
        Format: JSON with 'title' (max 15 chars), 'content' (approx 100-120 words), and 'hashtags' (array of 3 short strings including #).
        No emojis in the content.`;
      } else {
        prompt = `Write a social media post about "${topic}". 
        Style: Emotional, creative, personal, poetic, subjective tone. 
        Format: JSON with 'title' (catchy, max 15 chars), 'content' (approx 100-120 words), and 'hashtags' (array of 3 emotional/vibe strings including #).
        Use a few emojis to enhance emotion.`;
      }

      // 1. Generate Text
      const textResponse = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          systemInstruction: systemInstruction,
          responseMimeType: "application/json",
        }
      });

      const data = JSON.parse(textResponse.text || "{}");
      setGeneratedTitle(data.title || "无标题");
      setGeneratedText(data.content || "内容生成失败");
      setGeneratedHashtags(data.hashtags || [`#${topic}`]);
      setSeed(Math.floor(Math.random() * 100000));

    } catch (error) {
      console.error("Generation error:", error);
      setGeneratedText("生成出错，请重试。");
    } finally {
      setIsLoading(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setGeneratedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setGeneratedImage("");
  };

  // --- Export Functionality ---

  const copyParticipantLink = () => {
    // Note: We do NOT include the image in the URL because it's too large.
    const currentState: SharedState = {
      c: contentType, 
      l: labelType, 
      t: topic, 
      tt: generatedTitle, 
      tx: generatedText, 
      h: generatedHashtags,
      a: authorName, 
      lk: likes, 
      cc: commentsCount, 
      s: seed
    };
    
    const encoded = encodeState(currentState);
    const url = `${window.location.origin}${window.location.pathname}?s=${encoded}`;
    
    navigator.clipboard.writeText(url).then(() => {
        setCopySuccess(true);
        setTimeout(() => setCopySuccess(false), 2000);
        // Optional alert to explain why image might be missing in URL view
        if (generatedImage) {
            alert("链接已复制！\n注意：在线链接不包含您上传的本地图片。\n如需包含图片，请务必使用“导出离线 HTML 文件”。");
        }
    });
  };

  const downloadOfflineHTML = () => {
    // Generate the HTML for the comments section
    const commentsHTML = mockComments.map(c => `
      <div class="flex gap-3">
        <div class="w-8 h-8 rounded-full bg-gray-200 flex-shrink-0 overflow-hidden">
           <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=${c.avatarSeed}" alt="avatar" />
        </div>
        <div class="flex-1">
          <div class="text-xs text-gray-500 mb-1">${c.name}</div>
          <div class="text-sm text-gray-800">${c.content}</div>
        </div>
        <div class="flex flex-col items-center">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-gray-400"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
            <span class="text-[10px] text-gray-400 mt-0.5">${c.likeCount}</span>
        </div>
      </div>
    `).join('');

    // Generate Hashtags HTML (Inline Style)
    const hashtagsHTML = `<span class="text-blue-600 font-medium ml-1">${generatedHashtags.map(tag => `<span>${tag} </span>`).join('')}</span>`;

    // Generate Image HTML Section
    let imageSectionHTML = '';
    
    if (generatedImage) {
        imageSectionHTML = `
        <div class="w-full mb-4">
             <img src="${generatedImage}" class="w-full h-auto block" alt="Generated Content" />
        </div>`;
    } else {
        imageSectionHTML = `
        <div class="w-full aspect-[4/5] bg-gray-100 flex flex-col items-center justify-center text-gray-400 mb-4 overflow-hidden">
             <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mb-2 opacity-50"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>
             <span class="text-xs">未设置配图</span>
        </div>`;
    }

    // Generate label HTML
    let labelHTML = '';
    if (labelType === 'user') {
        labelHTML = `
        <span class="block mt-4 text-gray-600 bg-gray-50 p-3 rounded-md text-sm border border-gray-200 flex gap-2 items-start">
           <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mt-0.5 flex-shrink-0 text-gray-500"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
           <span>作者声明：该内容使用人工智能合成技术</span>
        </span>`;
    }
    
    let platformLabelHTML = '';
    if (labelType === 'platform') {
        platformLabelHTML = `
        <div class="absolute bottom-[60px] left-0 right-0 bg-gray-100 border-t border-gray-200 px-4 py-2 flex items-center gap-2 z-20">
             <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-gray-500"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>
             <span class="text-xs text-gray-600 font-medium">平台检测：本文内容疑似由 AI 生成</span>
        </div>`;
    }

    // Build the Full HTML String
    const htmlContent = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>实验材料</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&family=Noto+Sans+SC:wght@300;400;500;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', 'Noto Sans SC', sans-serif; background-color: #f3f4f6; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
    </style>
</head>
<body>
    <div class="relative w-[375px] h-[812px] bg-white rounded-[40px] shadow-2xl border-8 border-gray-900 overflow-hidden flex flex-col scale-[0.9] sm:scale-100">
        <!-- Status Bar -->
        <div class="h-12 bg-white flex justify-between items-center px-6 text-xs font-semibold select-none z-10">
          <span>9:41</span>
          <div class="flex gap-1">
            <div class="w-4 h-4 bg-gray-800 rounded-sm"></div>
            <div class="w-4 h-4 bg-gray-800 rounded-sm"></div>
          </div>
        </div>

        <!-- Header -->
        <div class="h-12 border-b border-gray-100 flex items-center justify-between px-4 sticky top-0 bg-white/90 backdrop-blur-sm z-10">
          <div class="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
            <span class="text-gray-400">&lt;</span>
          </div>
          <div class="flex items-center gap-2">
            <div class="w-8 h-8 bg-gradient-to-tr from-gray-200 to-gray-300 rounded-full overflow-hidden">
               <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=${authorName}" alt="avatar" />
            </div>
          </div>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-gray-600"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>
        </div>

        <!-- Content -->
        <div class="flex-1 overflow-y-auto bg-white pb-20 no-scrollbar">
            ${imageSectionHTML}
            <div class="px-5">
                <h2 class="text-lg font-bold text-gray-900 mb-3 leading-snug">${generatedTitle}</h2>
                <div class="text-gray-800 text-[15px] leading-relaxed whitespace-pre-wrap mb-4 font-normal">
                    ${generatedText}
                    ${hashtagsHTML}
                    ${labelHTML}
                </div>
                
                <div class="text-xs text-gray-400 mb-6">发布于 2024-10-24 10:30 · 北京</div>
                <div class="w-full h-px bg-gray-100 mb-4"></div>
                
                <div class="space-y-4">
                   <h3 class="text-sm font-semibold text-gray-700">共 ${commentsCount} 条评论</h3>
                   ${commentsHTML}
                </div>
            </div>
        </div>

        ${platformLabelHTML}

        <!-- Bottom Bar -->
        <div class="h-[60px] bg-white border-t border-gray-100 flex items-center justify-around px-2 pb-2 sticky bottom-0 z-30 text-gray-600">
           <div class="flex items-center gap-1.5 px-4 py-2 rounded-full">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
              <span class="text-xs font-medium">${likes}</span>
           </div>
           <div class="flex items-center gap-1.5 px-4 py-2 rounded-full">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/></svg>
              <span class="text-xs font-medium">${commentsCount}</span>
           </div>
           <div class="flex items-center gap-1.5 px-4 py-2 rounded-full">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" x2="15.42" y1="13.51" y2="17.49"/><line x1="15.41" x2="8.59" y1="6.51" y2="10.49"/></svg>
              <span class="text-xs font-medium">分享</span>
           </div>
        </div>
        <div class="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-32 h-1 bg-gray-800 rounded-full z-40"></div>
    </div>
</body>
</html>`;

    // Trigger Download
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const href = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = href;
    link.download = `experiment_material_${Date.now()}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(href);
  };

  // --- Render Functions (Converted from nested components to prevent focus loss) ---

  const renderControlPanel = () => (
    <div className="w-full lg:w-1/3 bg-white p-6 rounded-2xl shadow-sm border border-gray-200 flex flex-col gap-6 h-fit overflow-y-auto max-h-screen no-scrollbar">
      <div className="border-b border-gray-100 pb-4">
        <h1 className="text-2xl font-bold text-gray-800 mb-2">实验刺激材料生成器</h1>
        <p className="text-sm text-gray-500">
          配置实验变量，生成内容，然后选择分发方式。
        </p>
      </div>

      {/* Input Topic & Generate */}
      <div className="space-y-3">
        <label className="flex items-center gap-2 text-sm font-semibold text-gray-700">
          <RefreshCw size={18} />
          第一步：生成内容 (AI Generation)
        </label>
        <div className="flex gap-2">
            <input
            type="text"
            value={topic}
            placeholder="输入主题，例如：最新科技..."
            onChange={(e) => setTopic(e.target.value)}
            className="flex-1 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
            />
            <button
            onClick={generateContent}
            disabled={isLoading}
            className="bg-gray-900 hover:bg-gray-800 text-white px-4 rounded-lg font-medium transition-all flex items-center justify-center disabled:opacity-50 flex-shrink-0"
            >
            {isLoading ? <span className="animate-spin">⏳</span> : <span>生成</span>}
            </button>
        </div>
        <div className="grid grid-cols-2 gap-2 mt-2">
          <button
            onClick={() => setContentType("news")}
            className={`p-2 rounded-lg border text-xs font-medium transition-all ${
              contentType === "news"
                ? "bg-blue-50 border-blue-500 text-blue-700"
                : "bg-white border-gray-200 text-gray-600 hover:bg-gray-50"
            }`}
          >
            📰 客观新闻风格
          </button>
          <button
            onClick={() => setContentType("creative")}
            className={`p-2 rounded-lg border text-xs font-medium transition-all ${
              contentType === "creative"
                ? "bg-purple-50 border-purple-500 text-purple-700"
                : "bg-white border-gray-200 text-gray-600 hover:bg-gray-50"
            }`}
          >
            🎨 创意文案风格
          </button>
        </div>
      </div>
      
      {/* Manual Edit Section */}
      <div className="space-y-3 border-t border-gray-100 pt-4">
        <label className="flex items-center gap-2 text-sm font-semibold text-gray-700">
          <Edit3 size={18} />
          第二步：内容编辑 (手动输入 / 文案上传)
        </label>
        <p className="text-xs text-gray-400 -mt-2 mb-2">在此处直接修改或粘贴您的文案</p>
        
        <div className="space-y-2">
            <div className="flex flex-col gap-1">
                <span className="text-xs text-gray-500">标题 (Title)</span>
                <input
                    type="text"
                    value={generatedTitle}
                    onChange={(e) => setGeneratedTitle(e.target.value)}
                    placeholder="请输入或编辑标题..."
                    className="w-full p-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                />
            </div>
            
            <div className="flex flex-col gap-1">
                <span className="text-xs text-gray-500">正文 (Content)</span>
                <textarea
                    value={generatedText}
                    onChange={(e) => setGeneratedText(e.target.value)}
                    placeholder="请输入或编辑正文内容..."
                    rows={5}
                    className="w-full p-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                />
            </div>

            <div className="flex flex-col gap-1">
                <span className="text-xs text-gray-500">标签/话题 (Hashtags) - 用空格分隔</span>
                <input
                    type="text"
                    value={generatedHashtags.join(' ')}
                    onChange={(e) => setGeneratedHashtags(e.target.value.split(' '))}
                    placeholder="#话题1 #话题2"
                    className="w-full p-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-500 outline-none text-blue-600"
                />
            </div>
        </div>
      </div>

      {/* Upload Image Section */}
      <div className="space-y-3 border-t border-gray-100 pt-4">
        <label className="flex items-center gap-2 text-sm font-semibold text-gray-700">
          <ImageIcon size={18} />
          第三步：配图设置 (Image)
        </label>
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 flex flex-col items-center justify-center text-center hover:bg-gray-50 transition-colors relative bg-white group overflow-hidden h-32">
            <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
            />
            {generatedImage ? (
                <div className="relative w-full h-full flex items-center justify-center">
                    <img src={generatedImage} className="max-w-full max-h-full object-contain rounded-md" />
                    <button 
                        onClick={removeImage}
                        className="absolute top-1 right-1 bg-white rounded-full p-1 shadow-md hover:bg-red-50 z-20"
                        title="删除图片"
                    >
                         <X size={16} className="text-red-500" />
                    </button>
                </div>
            ) : (
                <>
                    <Upload size={20} className="text-gray-400 mb-1" />
                    <span className="text-xs text-gray-500 font-medium">点击上传图片</span>
                </>
            )}
        </div>
      </div>

      {/* Variable 2: Label Type */}
      <div className="space-y-3 border-t border-gray-100 pt-4">
        <label className="flex items-center gap-2 text-sm font-semibold text-gray-700">
          <Tag size={18} />
          变量 B: 标注方式 (Labeling)
        </label>
        <div className="flex flex-col gap-2">
          <button
            onClick={() => setLabelType("none")}
            className={`p-2 text-left rounded-lg border text-sm transition-all ${
              labelType === "none"
                ? "bg-green-50 border-green-500 text-green-700"
                : "bg-white border-gray-200 hover:bg-gray-50"
            }`}
          >
            <div className="font-medium">无标注 (Control Group)</div>
          </button>
          
          <button
            onClick={() => setLabelType("platform")}
            className={`p-2 text-left rounded-lg border text-sm transition-all ${
              labelType === "platform"
                ? "bg-orange-50 border-orange-500 text-orange-700"
                : "bg-white border-gray-200 hover:bg-gray-50"
            }`}
          >
            <div className="font-medium">平台检测标注 (Platform-Detected)</div>
          </button>
          
          <button
            onClick={() => setLabelType("user")}
            className={`p-2 text-left rounded-lg border text-sm transition-all ${
              labelType === "user"
                ? "bg-indigo-50 border-indigo-500 text-indigo-700"
                : "bg-white border-gray-200 hover:bg-gray-50"
            }`}
          >
            <div className="font-medium">用户自我声明 (User-Declared)</div>
          </button>
        </div>
      </div>

      <div className="border-t border-gray-200 pt-4">
        <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
            <Share2 size={16} />
            分发实验材料
        </h3>
        <div className="flex flex-col gap-3">
             <button
                onClick={downloadOfflineHTML}
                disabled={!generatedText}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-medium transition-all flex items-center justify-center gap-2 shadow-sm disabled:opacity-50 disabled:cursor-not-allowed group"
            >
                <Download size={18} />
                导出离线 HTML
            </button>
            
            <button
                onClick={copyParticipantLink}
                disabled={!generatedText}
                className="w-full bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 py-3 rounded-lg font-medium transition-all flex items-center justify-center gap-2 shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
                {copySuccess ? <Check size={18} className="text-green-600"/> : <Copy size={18} />}
                {copySuccess ? "链接已复制" : "复制链接 (无图)"}
            </button>
        </div>
      </div>
    </div>
  );

  const renderPhonePreview = (fullScreen = false) => (
    <div className={`flex-1 flex justify-center items-center ${fullScreen ? 'w-full h-full' : 'py-8 bg-gray-100 rounded-2xl border border-gray-200 shadow-inner'}`}>
      <div className="relative w-[375px] h-[812px] bg-white rounded-[40px] shadow-2xl border-8 border-gray-900 overflow-hidden flex flex-col scale-[0.9] sm:scale-100 transition-transform">
        {/* Status Bar Mock */}
        <div className="h-12 bg-white flex justify-between items-center px-6 text-xs font-semibold select-none z-10">
          <span>9:41</span>
          <div className="flex gap-1">
            <div className="w-4 h-4 bg-gray-800 rounded-sm"></div>
            <div className="w-4 h-4 bg-gray-800 rounded-sm"></div>
          </div>
        </div>

        {/* App Header */}
        <div className="h-12 border-b border-gray-100 flex items-center justify-between px-4 sticky top-0 bg-white/90 backdrop-blur-sm z-10">
          <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center cursor-pointer">
            <span className="text-gray-400">&lt;</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-tr from-gray-200 to-gray-300 rounded-full overflow-hidden">
               <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${authorName}`} alt="avatar" />
            </div>
          </div>
          <MoreHorizontal size={20} className="text-gray-600" />
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto bg-white pb-20 no-scrollbar">
          
          {/* Image Area - Condition Logic Updated */}
          {generatedImage ? (
             <div className="w-full mb-4">
                 <img src={generatedImage} alt="Generated" className="w-full h-auto block animate-in fade-in duration-500" />
             </div>
          ) : (
             <div className="w-full aspect-[4/5] bg-gray-100 flex flex-col items-center justify-center text-gray-400 mb-4 relative group overflow-hidden">
                <Upload size={48} className="mb-2 opacity-50"/>
                <span className="text-xs">请上传本地图片</span>
                <span className="text-xs text-gray-400 mt-1">（在控制面板上传）</span>
             </div>
          )}

          <div className="px-5">
            {/* Title */}
            <h2 className="text-lg font-bold text-gray-900 mb-3 leading-snug">
              {generatedTitle || "等待生成或手动输入..."}
            </h2>

            {/* Post Content */}
            <div className="text-gray-800 text-[15px] leading-relaxed whitespace-pre-wrap mb-4 font-normal">
              {generatedText || "请在左侧生成内容，或在“内容编辑”区直接手动输入文本..."}
              
              {/* Hashtags Inline */}
              <span className="text-blue-600 font-medium ml-1">
                 {generatedHashtags.map((tag, idx) => (
                    <span key={idx}>{tag} </span>
                 ))}
              </span>

              {/* Variable B: User Declared Label (Inline) */}
              {labelType === "user" && generatedText && (
                <span className="block mt-4 text-gray-600 bg-gray-50 p-3 rounded-md text-sm border border-gray-200 flex gap-2 items-start">
                   <User size={16} className="mt-0.5 flex-shrink-0 text-gray-500" />
                   <span>作者声明：该内容使用人工智能合成技术</span>
                </span>
              )}
            </div>
            
            <div className="text-xs text-gray-400 mb-6">发布于 2024-10-24 10:30 · 北京</div>

             <div className="w-full h-px bg-gray-100 mb-4"></div>

            {/* Comments Section Mock */}
            <div className="space-y-4">
               <h3 className="text-sm font-semibold text-gray-700">共 {commentsCount} 条评论</h3>
               {mockComments.map((comment) => (
                  <div key={comment.id} className="flex gap-3">
                    <div className="w-8 h-8 rounded-full bg-gray-200 flex-shrink-0 overflow-hidden">
                       <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${comment.avatarSeed}`} alt="avatar" />
                    </div>
                    <div className="flex-1">
                      <div className="text-xs text-gray-500 mb-1">{comment.name}</div>
                      <div className="text-sm text-gray-800">{comment.content}</div>
                    </div>
                    <div className="flex flex-col items-center">
                        <Heart size={14} className="text-gray-400" />
                        <span className="text-[10px] text-gray-400 mt-0.5">{comment.likeCount}</span>
                    </div>
                  </div>
               ))}
            </div>

          </div>
        </div>

        {/* Variable B: Platform Detected Label (Bottom Overlay) */}
        {labelType === "platform" && (
          <div className="absolute bottom-[60px] left-0 right-0 bg-gray-100 border-t border-gray-200 px-4 py-2 flex items-center gap-2 z-20">
             <Info size={14} className="text-gray-500" />
             <span className="text-xs text-gray-600 font-medium">
               平台检测：本文内容疑似由 AI 生成
             </span>
          </div>
        )}

        {/* Bottom Interaction Bar */}
        <div className="h-[60px] bg-white border-t border-gray-100 flex items-center justify-around px-2 pb-2 sticky bottom-0 z-30 text-gray-600">
           <div className="flex items-center gap-1.5 px-4 py-2 rounded-full hover:bg-gray-50 cursor-pointer transition-colors">
              <Heart size={22} />
              <span className="text-xs font-medium">{likes}</span>
           </div>
           <div className="flex items-center gap-1.5 px-4 py-2 rounded-full hover:bg-gray-50 cursor-pointer transition-colors">
              <MessageCircle size={22} />
              <span className="text-xs font-medium">{commentsCount}</span>
           </div>
           <div className="flex items-center gap-1.5 px-4 py-2 rounded-full hover:bg-gray-50 cursor-pointer transition-colors">
              <Share2 size={22} />
              <span className="text-xs font-medium">分享</span>
           </div>
        </div>
        
        {/* Home Indicator */}
        <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-32 h-1 bg-gray-800 rounded-full z-40"></div>
      </div>
    </div>
  );

  // --- Render logic for Participant View vs Experimenter View ---
  
  if (isParticipantView) {
      return (
          <div className="min-h-screen w-full flex items-center justify-center bg-[#f3f4f6]">
              {renderPhonePreview(true)}
          </div>
      );
  }

  return (
    <div className="min-h-screen p-4 lg:p-8 max-w-[1600px] mx-auto flex flex-col lg:flex-row gap-8">
      {renderControlPanel()}
      {renderPhonePreview()}
    </div>
  );
};

const root = createRoot(document.getElementById("root")!);
root.render(<App />);